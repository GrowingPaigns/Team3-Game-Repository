﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using TeamProj__menu_base_.States;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamProj__menu_base_.Models
{
    public class Score
    {
        public string PlayerName { get; set; }

        public int Value { get; set; }

        public Score()
        {

        }

        public int Score1;
        public int Score2;

        private SpriteFont _font;

        public Score(SpriteFont font)
        {
            _font = font;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.DrawString(_font, Score1.ToString(), new Vector2(591, 150), Color.White);
            spriteBatch.DrawString(_font, Score2.ToString(), new Vector2(673, 150), Color.White);
        }

    }
}
