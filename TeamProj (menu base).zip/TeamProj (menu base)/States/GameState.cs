﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeamProj__menu_base_.Sprites;
using TeamProj__menu_base_.Managers;
using TeamProj__menu_base_.Models;

namespace TeamProj__menu_base_.States
{
    public class GameState : State
    {
        private List<Sprite> _sprites;

       


        public GameState(Game1 game, ContentManager content)
          : base(game, content)
        {
        }

        public override void LoadContent()
        {

            _sprites = new List<Sprite>()
            {



                new Sprite(_content.Load<Texture2D>("Grass"))
                {
                     Layer = 0.0f,
                     Position = new Vector2(Game1.ScreenWidth / 2, Game1.ScreenHeight / 2),
                },

            };
        }


        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            //Draws all Sprites in Sprite list
            spriteBatch.Begin(SpriteSortMode.FrontToBack);

            foreach (var sprite in _sprites)
                sprite.Draw(gameTime, spriteBatch);

            spriteBatch.End();


        }




        public override void PostUpdate(GameTime gameTime)
        {

        }

        public override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                _game.ChangeState(new MenuState(_game, _content));

            foreach (var sprite in _sprites)
            {
                sprite.Update(gameTime, _sprites);
                sprite.Update(gameTime);
            }

        }
    }
}
