﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using TeamProj__menu_base_.Controls;
using TeamProj__menu_base_.Sprites;

namespace TeamProj__menu_base_.States
{
    public class MenuState : State
    {
        private List<Component> _components;
        
        public MenuState(Game1 game, ContentManager content)
          : base(game, content)
        {
            
        }


        public override void LoadContent()
        {
            var buttonTexture = _content.Load<Texture2D>("Button");
            var buttonFont = _content.Load<SpriteFont>("Font");

            
            _components = new List<Component>()
            {
                new Sprite(_content.Load<Texture2D>("Sky"))
                {
                  Layer = 0f,
                  Position = new Vector2(Game1.ScreenWidth / 2, Game1.ScreenHeight / 2),
                },


                new Button(buttonTexture, buttonFont)
                {
                    Text = "New Game",
                    Position = new Vector2((Game1.ScreenWidth / 2),(Game1.ScreenHeight / 2) - 400),
                    Click = new EventHandler(Button_NewGame_Clicked),
                    Layer = 0.5f
                },
                new Button(buttonTexture, buttonFont)
                {
                    Text = "Load Game",
                    Position = new Vector2((Game1.ScreenWidth / 2) + 300, 300),
                    Click = new EventHandler(Button_LoadGame_Clicked),
                    Layer = 0.5f
                },
                new Button(buttonTexture, buttonFont)
                {
                    Text = "Highscores",
                    Position = new Vector2(640, 400),
                    Click = new EventHandler(Button_Highscores_Clicked),
                    Layer = 0.5f
                },
                new Button(buttonTexture, buttonFont)
                {
                    Text = "Quit",
                    Position = new Vector2(Game1.ScreenWidth / 2, (Game1.ScreenHeight / 2) + 200),
                    Click = new EventHandler(Button_Quit_Clicked),
                    Layer = 0.5f
                },
            };

            
    }




        private void Button_NewGame_Clicked(object sender, EventArgs args)
        {
            _game.ChangeState(new GameState(_game, _content));
        }

        private void Button_LoadGame_Clicked(object sender, EventArgs args)
        {
            Console.WriteLine("Load Game");
        }

        private void Button_Highscores_Clicked(object sender, EventArgs args)
        {
            _game.ChangeState(new HighscoresState(_game, _content));
        }

        private void Button_Quit_Clicked(object sender, EventArgs args)
        {
            _game.Exit();
        }



        public override void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Begin(SpriteSortMode.FrontToBack);

            foreach (var component in _components)
            component.Draw(gameTime, spriteBatch);

            spriteBatch.End();
        }


        public override void Update(GameTime gameTime)
        {
            foreach (var component in _components)
                component.Update(gameTime);
        }


        public override void PostUpdate(GameTime gameTime)
        {
            // remove sprites if they're not needed
        }

        

      

    }
}

